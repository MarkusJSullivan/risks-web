"""The Data Protection Risk Game: a card game for practising data protection impact assessments."""

from .cards import CardSet

__all__ = ["CardSet"]
__version__ = "0.7.0"

"""Single-player game for the pool model (v0.8+), on top of the pure rules in ``engine``.

A run is endless: a project is one quarter, four quarters are a year, and the risk deck is shuffled again
when it runs out. Every year brings a new purse of coins; the run ends when the coins are gone, and the score
is the number of quarters it lasted.

At the end of a quarter every risk that still has a High goal needs a recommendation, stop or consult the
authority (Art. 36 GDPR). Management, a card that changes every year, decides: it may follow the
recommendation or not share the assessment and go live as planned. Every risk that went live is on the books
and can bring a report, an inquiry or a lawsuit at the end of each year.

The state is plain JSON and lives on the server. ``Game`` implements the ``GameLogic`` interface of
``server.py``: ``new_game``, ``apply`` and ``view``. No I/O, no clock; all randomness is seeded (the risk
deck, the card pile, events), so a game can be replayed from its seed, its hand size and its actions.

Actions: ``{"type": "play", "card": "<id>"}`` and ``{"type": "end_project"}``.
"""
from __future__ import annotations

import copy
import random
from typing import Any

from . import engine, risk_check
from .cards import CardSet
from .server import GameError, State

PLAYABLE_TYPES = ("standard", "learning", "permanent")
ACTION_KEYS = ("type", "card", "target", "cards", "advice")   # what an action can carry; the log keeps these


class Game:
    def __init__(self, cs: CardSet) -> None:
        self.cs = cs
        self.rules = cs.rules
        self.cards = {c["id"]: c for c in cs.data["measureCards"] if c["type"] in PLAYABLE_TYPES}
        self.risks = {r["id"]: r for r in cs.risks}
        self.strategy = {c["id"]: c for c in cs.data["measureCards"] if c["type"] == "strategy"}
        self.events = list(cs.data.get("eventCards", []))
        self.management = {c["id"]: c for c in cs.data["managementCards"]}
        self.goal_names = {g["id"]: g["name"]["en"] for g in cs.data["game"]["protectionGoals"]}
        per = self.rules["risksPerProject"]
        if len(per) != self.rules["quartersPerYear"] or not per or not 0 < max(per) <= len(self.risks):
            raise ValueError("rules.json: risksPerProject must list every quarter of a year and fit the deck")

    # -- GameLogic ---------------------------------------------------------------------------------
    def new_game(self, seed: int | None = None, hand_size: int | None = None,
                 mode: str | None = None, difficulty: str | None = None) -> State:
        """Start a run. The hand size, the difficulty (the size of the yearly purse) and the mode of the
        central cards are the player's choice."""
        mode = self.rules["centralModeDefault"] if mode is None else mode
        if not isinstance(mode, str) or mode not in self.rules["centralModes"]:
            raise GameError(f"mode must be one of: {', '.join(self.rules['centralModes'])}")
        difficulty = self.rules["difficultyDefault"] if difficulty is None else difficulty
        if not isinstance(difficulty, str) or difficulty not in self.rules["difficulties"]:
            raise GameError(f"difficulty must be one of: {', '.join(self.rules['difficulties'])}")
        size = self.rules["handSizeDefault"] if hand_size is None else hand_size
        lo, hi = self.rules["handSizeMin"], self.rules["handSizeMax"]
        if isinstance(size, bool) or not isinstance(size, int) or not lo <= size <= hi:
            raise GameError(f"hand size must be a whole number from {lo} to {hi}")
        if seed is None:
            seed = random.SystemRandom().randrange(1 << 31)
        deck = sorted(self.risks)
        random.Random(seed).shuffle(deck)
        cards = sorted([*self.cards, *self.strategy])   # every card that can be played: one deck
        random.Random(f"{seed}-deck").shuffle(cards)
        state: State = {"version": self.cs.version, "seed": seed, "deck": deck, "taken": 0, "shuffles": 0,
                        "phase": "project", "project": 0, "bonus": 0, "legal": 0,
                        "difficulty": difficulty, "effort": self._purse(difficulty),
                        "learned": [], "central": {}, "paid": {}, "eventCount": 0, "results": [],
                        "mode": mode, "upkeepPaid": 0,
                        "live": [], "liveCount": 0, "consulting": [], "waiting": [], "retry": [],
                        "legalByKind": {}, "legalByRisk": {},   # where the lawyers' coins went
                        "actions": [],   # every action the rules accepted, in order: with the seed, a replay
                        "yearShipped": 0, "yearCancelled": 0, "management": None,
                        "handSize": size, "hand": cards[:size], "pile": cards[size:]}
        self._start_project(state)
        return state

    def apply(self, state: State, action: dict[str, Any]) -> tuple[State, list[dict[str, Any]]]:
        if state["phase"] != "project":
            raise GameError("the game is over")
        # the finished quarters and the actions are never changed, only added to: copying the list is enough
        # (and much faster than copying every entry)
        new = copy.deepcopy({k: v for k, v in state.items() if k not in ("results", "actions")})
        new["results"] = list(state["results"])
        new["actions"] = list(state.get("actions", []))
        kind = action.get("type")
        if kind == "play":
            card, target = action.get("card"), action.get("target")
            events = self._play(new, card, target, draw_event=False)
            if isinstance(card, str) and card in self.cards:   # a measure: an event card may answer it
                before = self.view(new)
                response = self._draw_event(new)
                if response:   # the table as it was before the answer, so the page can show it first
                    response[0]["before"] = before
                events += response
        elif kind == "end_project":
            events = self._end_project(new, action.get("advice"), asked=True)
        elif kind == "replace":
            events = self._replace(new, action.get("cards"))
        else:
            raise GameError("unknown action")
        new["actions"].append({k: copy.deepcopy(action[k]) for k in ACTION_KEYS if k in action})   # the log
        return new, events

    def replay(self, seed: int, actions: list[dict[str, Any]], hand_size: int | None = None,
               mode: str | None = None, version: str | None = None, difficulty: str | None = None) -> State:
        """Rebuild a run from what determines it: card set version, seed, hand size, mode and the actions.

        The result is the state the run had (the same dictionary). An action the rules refuse raises
        GameError, so a log of other rules or of another version is noticed and not played on wrongly.
        """
        if version is not None and version != self.cs.version:
            raise GameError(f"this run was played with card set {version}, this game has {self.cs.version}")
        state = self.new_game(seed, hand_size, mode, difficulty)
        for action in actions:
            state, _ = self.apply(state, action)
        return state

    def replay_state(self, state: State) -> State:
        """The state of a saved run, rebuilt from its seed and its actions (shows nothing else is in it)."""
        return self.replay(state["seed"], state.get("actions", []), state["handSize"], state["mode"],
                           state.get("version"), state.get("difficulty"))

    def view(self, state: State) -> dict[str, Any]:
        risks = []
        for rid in state["risks"]:
            levels = self._levels(state, rid)
            risks.append({"id": rid, "title": self.risks[rid]["title"]["en"],
                          "goals": levels, "resolved": engine.is_resolved(levels, self.rules),
                          "lows": engine.low_goals(levels, self.rules), "retry": rid in state["retry"]})
        out: dict[str, Any] = {
            "phase": state["phase"], "project": state["project"] + 1, "year": self._year(state),
            "quarter": state["project"] % self.rules["quartersPerYear"] + 1,
            "quartersPerYear": self.rules["quartersPerYear"],
            "effort": state["effort"], "effortBudget": self._purse(state["difficulty"]),
            "difficulty": state["difficulty"],
            "handSize": state["handSize"], "slotsLeft": self._slots_left(state), "bonus": state["bonus"],
            "legal": state["legal"], "mode": state["mode"], "upkeep": self._upkeep(state),
            "upkeepPaid": state["upkeepPaid"], "upkeepPer": self._mode(state)["upkeepPer"],
            "upkeepYear": self._upkeep_year(state), "risks": risks,
            "management": self._management_view(state),
            "live": {"count": len(state["live"]),
                     "high": sum(1 for e in state["live"] if e["score"] > self._high_from())},
            "consulting": [self.risks[e["id"]]["title"]["en"] for e in state["consulting"]],
            "played": list(state["played"]), "paid": state["paid"],
            "central": sorted(state["central"].values()),
            "results": state["results"],
            "replace": self._replace_info(state),
            "event": state["event"],
            "happened": [dict(h) for h in state["happened"]],
        }
        if state["phase"] == "project":
            held, swappable = set(state["hand"]), set(self._swappable(state))
            out["market"] = [{"id": cid, **self._check(state, cid), "replaceable": cid in swappable}
                             for cid in self.cards if cid in held]   # the measures in the hand
            out["strategy"] = [{"id": cid, "strategy": True, **self._check_strategy(state, cid),
                                "replaceable": cid in swappable}
                               for cid in self.strategy if cid in held]   # the strategy cards in the hand
        else:
            out["score"] = self._score(state)
            out["debrief"] = self._debrief(state)   # only when the run is over
        return out

    # -- helpers -----------------------------------------------------------------------------------
    def _active(self, state: State) -> list[dict[str, Any]]:
        held = list(state["central"].values())   # a central card built this project is also in "played"
        ids = [*held, *(i for i in state["played"] if i not in held)]
        return [self._boosted(self.cards[i], state["boosts"].get(i, 0))
                for i in ids if i in self.cards and i not in state["disabled"]]   # traps are no measures

    @staticmethod
    def _boosted(card: dict[str, Any], steps: int) -> dict[str, Any]:
        """A strategy card made this measure stronger: every reduction gets ``steps`` better."""
        if not steps:
            return card
        effects = [{**e, "probability": e["probability"] + (steps if e["probability"] > 0 else 0),
                    "impact": e["impact"] + (steps if e["impact"] > 0 else 0)} for e in card["effects"]]
        return {**card, "effects": effects}

    def _levels(self, state: State, rid: str) -> list[dict[str, Any]]:
        shifts = {goal: tuple(v) for goal, v in state["shifts"].get(rid, {}).items()}
        levels = engine.risk_goal_levels(self.risks[rid], self._active(state), self.rules, shifts)
        for extra in state.get("extraGoals", {}).get(rid, []):   # a goal that joined during the project
            since = state["played"][extra["since"]:]   # only the cards played since the goal joined move it
            ids = [i for i in since if i in self.cards and i not in state["disabled"]]
            later = [self._boosted(self.cards[i], state["boosts"].get(i, 0)) for i in ids]
            start = {"goal": extra["goal"], "probability": extra["probability"], "impact": extra["impact"]}
            levels += engine.risk_goal_levels({"goals": [start]}, later, self.rules, shifts)
        return levels

    def _slots_left(self, state: State) -> int:
        # every kind of card takes a slot; an event can take one away
        return self.rules["maxCardsPerProject"] - len(state["played"]) - state["slotLoss"]

    def _year(self, state: State) -> int:
        return state["project"] // self.rules["quartersPerYear"] + 1

    def _take_risks(self, state: State, n: int, avoid: list[str]) -> list[str]:
        """The next risks of the deck, none of them twice in a quarter. A used-up deck is shuffled again."""
        taken: list[str] = []
        while len(taken) < n:
            if state["taken"] >= len(state["deck"]):
                state["shuffles"] += 1
                state["deck"] = sorted(r for r in self.risks if r not in avoid and r not in taken)
                random.Random(f"{state['seed']}-risks{state['shuffles']}").shuffle(state["deck"])
                state["taken"] = 0
            rid = state["deck"][state["taken"]]
            state["taken"] += 1
            if rid not in avoid and rid not in taken:
                taken.append(rid)
        return taken

    def _purse(self, difficulty: str) -> int:
        """The coins of a new year: the base purse of the rules times the factor of the difficulty."""
        return round(self.rules["effortBudget"] * self.rules["difficulties"][difficulty]["coinFactor"])

    def _mode(self, state: State) -> dict[str, Any]:
        """The price rules of the central cards: simple, or advanced with a higher price and an upkeep."""
        return self.rules["centralModes"][state["mode"]]

    def _upkeep(self, state: State) -> int:
        """What the central cards cost when this quarter ends: every quarter, or only at a year end."""
        mode = self._mode(state)
        year_end = (state["project"] + 1) % self.rules["quartersPerYear"] == 0
        due = mode["upkeepPer"] == "quarter" or year_end
        return len(state["central"]) * mode["upkeep"] if due else 0

    def _upkeep_year(self, state: State) -> int:
        """What the central cards cost per year when the upkeep is paid yearly (otherwise 0)."""
        mode = self._mode(state)
        return len(state["central"]) * mode["upkeep"] if mode["upkeepPer"] == "year" else 0

    def _high_from(self) -> float:
        """The highest score that is still below High."""
        levels = self.rules["riskLevels"]
        return levels[[lv["level"]["en"] for lv in levels].index(self.rules["resolvedBelow"]) - 1]["range"][1]

    def _draw_management(self, state: State) -> str:
        """The management of the year: the cards come in a shuffled order, and again after the last one."""
        ids, year = sorted(self.management), self._year(state) - 1
        random.Random(f"{state['seed']}-management{year // len(ids)}").shuffle(ids)
        return ids[year % len(ids)]

    def _management_view(self, state: State) -> dict[str, Any] | None:
        card = self.management.get(state["management"])
        return card and {"id": card["id"], "title": card["title"]["en"], "hint": card["hint"]["en"]}

    def _start_project(self, state: State) -> None:
        per = self.rules["risksPerProject"]
        if state["project"] % self.rules["quartersPerYear"] == 0:
            state["management"] = self._draw_management(state)
        state["retry"], state["waiting"] = state["waiting"], []   # a stopped project returns
        state["risks"] = [*state["retry"], *self._take_risks(state, per[state["project"] % len(per)],
                                                             state["retry"])]
        state["played"], state["paid"] = [], {}
        # what events did to this project (all of it ends with the project)
        state.update(shifts={}, extraGoals={}, disabled=[], slotLoss=0, cap=None, event=None,
                     boosts={}, protected=[], happened=[])
        if state["project"] > 0:   # a new round: the hand stays, everything else is shuffled back in
            self._rebuild_pile(state)
            self._refill(state)

    def _rebuild_pile(self, state: State) -> None:
        """The pile never runs out: every card that is neither in the hand nor on the board goes back in."""
        held = set(state["hand"]) | set(state["central"].values())
        rest = sorted(c for c in [*self.cards, *self.strategy] if c not in held)
        random.Random(f"{state['seed']}-pile{state['project']}").shuffle(rest)
        state["pile"] = rest

    @staticmethod
    def _refill(state: State) -> None:
        """Draw from the top of the pile until the hand has its size again."""
        while len(state["hand"]) < state["handSize"] and state["pile"]:
            state["hand"].append(state["pile"].pop(0))

    # -- strategy cards: like event cards, but you choose the target -------------------------------
    def _strategy_targets(self, state: State, cid: str) -> list[str]:
        """What a strategy card can be played on right now: measures in play, or risks."""
        card, kind = self.strategy[cid], self.strategy[cid]["target"]
        measures = [i for i in state["played"] if i in self.cards]
        if kind == "switched_off":
            return [i for i in state["disabled"] if i in self.cards]
        live = [i for i in measures if i not in state["disabled"]]
        if "boost" in card["effect"]:   # only measures that reduce something, and only once each
            return [i for i in live if not state["boosts"].get(i)
                    and any(e["probability"] > 0 or e["impact"] > 0 for e in self.cards[i]["effects"])]
        if "protect" in card["effect"]:
            return [i for i in live if i not in state["protected"]]
        return live

    def _check_strategy(self, state: State, cid: str) -> dict[str, Any]:
        card = self.strategy[cid]
        cost = card["cost"]
        targets = self._strategy_targets(state, cid)
        reason = None
        if cid not in state["hand"]:
            reason = "not in your hand"
        elif cid in state["played"]:
            reason = "already played in this project"
        elif self._slots_left(state) <= 0:
            reason = "no action left"
        elif cost > state["effort"]:
            reason = "not enough coins"
        elif state["cap"] is not None and cost > self._cap_limit(state):
            reason = f"budget freeze: at most {self._cap_limit(state)} coins now"
        elif not targets and card["target"] != "none":
            reason = {"measure": "no measure in play to use it on",
                      "switched_off": "nothing was switched off"}[card["target"]]
        return {"cost": cost, "playable": reason is None, "reason": reason, "targetKind": card["target"],
                "targets": targets}

    def _play_strategy(self, state: State, cid: str, target: Any) -> list[dict[str, Any]]:
        check = self._check_strategy(state, cid)
        if not check["playable"]:
            raise GameError(check["reason"])
        if check["targetKind"] != "none" and target not in check["targets"]:
            raise GameError("choose what to use it on")
        effect = self.strategy[cid]["effect"]
        if effect.get("boost"):
            state["boosts"][target] = state["boosts"].get(target, 0) + effect["boost"]
        if effect.get("protect"):
            state["protected"].append(target)
        if effect.get("repair"):
            state["disabled"].remove(target)
        state["effort"] -= check["cost"]
        state["paid"][cid] = check["cost"]
        state["played"].append(cid)
        state["hand"].remove(cid)   # a played strategy card leaves the hand, a new card is drawn
        self._refill(state)
        state["cap"] = None
        state["event"] = None
        return [{"event": "played", "card": cid, "cost": check["cost"], "target": target}]

    # -- event cards -------------------------------------------------------------------------------
    def _cap_limit(self, state: State) -> int:
        """What a budget freeze lets the next measure cost: a share of the remaining coins, at least 1."""
        return max(1, int(state["effort"] * state["cap"]))

    def _draw_event(self, state: State) -> list[dict[str, Any]]:
        """After a measure an event card may be played: it can change coins, slots, risks or cards."""
        chance = self.rules.get("eventChance", 0)
        if not self.events or chance <= 0:
            return []
        rng = random.Random(f"{state['seed']}-{state['project']}-event{state['eventCount']}")
        state["eventCount"] += 1
        if rng.random() >= chance:
            return []
        card = rng.choices(self.events, weights=[c["weight"] for c in self.events])[0]
        notes = self._apply_effect(state, card["effect"], rng, card["id"])
        record = {"event": "event_card", "card": card["id"], "title": card["title"]["en"],
                  "text": card["rules"]["en"], "notes": notes, "dare": bool(card["effect"].get("dare")),
                  "endsProject": bool(card["effect"].get("endProject"))}
        events = [record]
        if state.pop("endNow", False):
            record["endsProject"] = True
        if record["endsProject"]:
            events += self._end_project(state)
        else:
            state["event"] = {k: v for k, v in record.items() if k != "event"}
            state["happened"].append(dict(state["event"]))   # every event card of this project, oldest first
        return events

    def _apply_effect(self, state: State, eff: dict[str, Any], rng: random.Random,
                      card_id: str = "") -> list[str]:
        """Apply one event effect and return what happened, in plain words, for the player."""
        notes: list[str] = []
        coins = eff.get("coins", 0)
        if coins:
            before = state["effort"]
            state["effort"] = max(0, before + coins)
            notes.append(f"{'Gain' if coins > 0 else 'Lose'} {abs(state['effort'] - before)} coins")
        if eff.get("slots", 0) > 0:
            state["slotLoss"] -= eff["slots"]
            notes.append(f"{eff['slots']} more action{'s' if eff['slots'] > 1 else ''} for this project")
        if eff.get("slots", 0) < 0:
            lost = min(-eff["slots"], max(0, self._slots_left(state)))
            state["slotLoss"] += lost
            notes.append(f"{lost} action{'s are' if lost != 1 else ' is'} gone for this project"
                         if lost else "No free action left to lose")
        if eff.get("capNext"):
            state["cap"] = eff["capNext"]
            notes.append(f"Your next measure may cost at most {self._cap_limit(state)} coins")
        if eff.get("risk"):
            notes += self._shift_risks(state, eff["risk"], rng)
        measures = [i for i in state["played"] if i in self.cards]
        if eff.get("disableLast") and measures:
            last = measures[-1]
            if last in state["protected"]:
                notes.append(f"{self.cards[last]['title']['en']} is protected: nothing happens")
            else:
                state["disabled"].append(last)
                notes.append(f"{self.cards[last]['title']['en']} does nothing for the rest of this project")
        if eff.get("trap"):
            if self._slots_left(state) > 0:
                state["played"].append(card_id)
                notes.append("It takes an action and protects nobody")
            else:
                notes.append("No free action: it is thrown out")
        if eff.get("wing"):
            notes += self._wing_it(state, eff["wing"], rng)
        if eff.get("reset"):
            notes += self._reset_project(state)
        if eff.get("newGoal"):
            notes += self._new_goal(state, rng)
        if eff.get("endProject"):
            notes.append("The project ends now")
        return notes

    def _new_goal(self, state: State, rng: random.Random) -> list[str]:
        """A goal joins one risk of this project: the first goal, in the order of the letters, that the risk
        lacks. Its figure starts on the same space every time; only cards played from now on move it."""
        rid = rng.choice(state["risks"])
        joined = state["extraGoals"].get(rid, [])
        have = {g["goal"] for g in self.risks[rid]["goals"]} | {e["goal"] for e in joined}
        goal = next((g for g in sorted(self.goal_names) if g not in have), None)
        if goal is None:
            return ["Every goal is already on this risk"]
        joined.append({"goal": goal, "since": len(state["played"]), **self.rules["newGoalStart"]})
        state["extraGoals"][rid] = joined
        return [f"{self.goal_names[goal]} joins {self.risks[rid]['title']['en']}"]

    def _reset_project(self, state: State) -> list[str]:
        """A new project manager: everything played in this project is gone, the coins stay spent."""
        gone = list(state["played"])
        gone += [cid for cid in state["central"].values() if cid not in gone]   # all yellow cards go too
        state["central"] = {}
        for extras in state["extraGoals"].values():
            for extra in extras:
                extra["since"] = 0   # nothing is played any more: the new goals start again
        state["played"], state["paid"] = [], {}
        state.update(boosts={}, protected=[], disabled=[], cap=None)
        return [f"{len(gone)} card{'s' if len(gone) != 1 else ''} gone, the coins are spent"
                if gone else "Nothing was played yet, so nothing is lost"]

    def _wing_it(self, state: State, count: int, rng: random.Random) -> list[str]:
        """Play random cards of the hand, whatever they are. A card that cannot be played ends the project."""
        hand = [c for c in state["hand"] if c in self.cards and c not in state["played"]]   # measures only
        notes = []
        for cid in rng.sample(hand, min(count, len(hand))):
            title = self.cards[cid]["title"]["en"]
            check = self._check(state, cid)
            if not check["playable"]:
                notes.append(f"{title} cannot be played ({check['reason']}): the project ends")
                state["endNow"] = True
                break
            self._play(state, cid, draw_event=False)
            notes.append(f"Played {title} for {check['cost']} coins")
        return notes

    def _shift_risks(self, state: State, spec: dict[str, Any], rng: random.Random) -> list[str]:
        """Make goals of the risks in this project worse (delta > 0) or better (delta < 0)."""
        targets = list(state["risks"]) if spec["pick"] == "all" else [rng.choice(state["risks"])]
        axis = 0 if spec["axis"] == "probability" else 1
        notes = []
        for rid in targets:
            levels = self._levels(state, rid)
            goals = levels if spec["goal"] == "all" else [max(levels, key=lambda g: g["score"])]
            for g in goals:
                shift = state["shifts"].setdefault(rid, {}).setdefault(g["goal"], [0, 0])
                shift[axis] += spec["delta"]
                notes.append(f"{self.risks[rid]['title']['en']}: {self.goal_names[g['goal']]} "
                             f"{spec['axis']} {'+' if spec['delta'] > 0 else '-'}{abs(spec['delta'])}")
        return notes

    def _swappable(self, state: State) -> list[str]:
        """Cards of the hand that can be swapped: any card of the hand that was not played this project."""
        return [c for c in state["hand"] if c not in state["played"]]

    def _replace_info(self, state: State) -> dict[str, Any]:
        """What the swap button needs: how many cards, what it costs, and whether it can be used now."""
        if state["phase"] != "project":
            return {"enabled": False, "reason": "the game is over"}
        count = min(self.rules["replaceCards"], len(self._swappable(state)), len(state["pile"]))
        reason = None
        if not self._swappable(state):
            reason = "no cards left to swap"
        elif not state["pile"]:
            reason = "the pile is empty"
        elif self.rules["replaceCost"] > state["effort"]:
            reason = "not enough coins"
        return {"enabled": reason is None, "reason": reason, "cards": count,
                "cost": self.rules["replaceCost"]}

    def _check(self, state: State, cid: str) -> dict[str, Any]:
        """Cost of a card now and, if it cannot be played, why not."""
        card = self.cards[cid]
        cost = engine.effort_cost(card, state["learned"])
        if card["type"] == "permanent":
            cost *= self._mode(state)["costFactor"]
        reason = None
        family_cards = [self.cards[i] for i in state["played"] if i in self.cards]
        if cid not in state["hand"]:
            reason = "not in your hand"
        elif cid in state["played"]:
            reason = "already played in this project"
        elif card["type"] == "permanent" and state["central"].get(card["family"]):
            held = self.cards[state["central"][card["family"]]]
            if held["rung"] >= card["rung"]:
                reason = "already in play" if held["id"] == cid else "a stronger rung is in play"
        elif card["type"] != "permanent" and any(c["family"] == card["family"] for c in family_cards):
            reason = "this ladder is already used in this project"
        if reason is None and self._slots_left(state) <= 0:
            reason = "no action left"
        if reason is None and cost > state["effort"]:
            reason = "not enough coins"
        if reason is None and state["cap"] is not None and cost > self._cap_limit(state):
            reason = f"budget freeze: at most {self._cap_limit(state)} coins now"
        return {"cost": cost, "playable": reason is None, "reason": reason}

    def _play(self, state: State, cid: Any, target: Any = None,
              draw_event: bool = True) -> list[dict[str, Any]]:
        if isinstance(cid, str) and cid in self.strategy:
            return self._play_strategy(state, cid, target)
        if not isinstance(cid, str) or cid not in self.cards:
            raise GameError("unknown card")
        check = self._check(state, cid)
        if not check["playable"]:
            raise GameError(check["reason"])
        card = self.cards[cid]
        state["effort"] -= check["cost"]
        state["paid"][cid] = check["cost"]
        if card["type"] == "permanent":
            old = state["central"].get(card["family"])
            if old in state["played"]:
                state["played"].remove(old)   # a stronger rung replaces it on the table
            state["central"][card["family"]] = cid   # stays in play in later projects, without a slot then
        state["played"].append(cid)
        if card["type"] == "learning" and cid not in state["learned"]:
            state["learned"].append(cid)
        if card["type"] != "learning":   # a shareable card stays in the hand; any other card is replaced
            state["hand"].remove(cid)
            self._refill(state)
        state["cap"] = None   # a budget freeze only holds for one measure
        state["event"] = None
        played = [{"event": "played", "card": cid, "cost": check["cost"]}]
        return played + self._draw_event(state) if draw_event else played

    def _replace(self, state: State, chosen: Any) -> list[dict[str, Any]]:
        """Pay the swap price, drop the chosen cards and draw as many from the top of the pile."""
        info = self._replace_info(state)
        if not info["enabled"]:
            raise GameError(info["reason"])
        if (not isinstance(chosen, list) or len(set(chosen)) != len(chosen)
                or not all(isinstance(c, str) for c in chosen)):
            raise GameError("choose the cards to swap")
        if len(chosen) != info["cards"]:
            raise GameError(f"choose exactly {info['cards']} cards to swap")
        if not set(chosen) <= set(self._swappable(state)):
            raise GameError("only cards in your hand can be swapped")
        state["effort"] -= info["cost"]
        for cid in chosen:
            state["hand"].remove(cid)   # back in the pile with the next round
        drawn = [state["pile"].pop(0) for _ in chosen]
        state["hand"] += drawn
        return [{"event": "replaced", "dropped": list(chosen), "drawn": drawn, "cost": info["cost"]}]

    def _score(self, state: State) -> int:
        """How many quarters the run lasted."""
        return state["project"]

    def _end_project(self, state: State, advice: Any = None, asked: bool = False) -> list[dict[str, Any]]:
        """End the quarter. ``asked``: the player pressed the button and must advise on every risk at High.
        When an event ends the quarter nobody advised, and management goes live as planned."""
        lows, per_risk = 0, []
        for rid in state["risks"]:
            levels = self._levels(state, rid)
            n = engine.low_goals(levels, self.rules)
            lows += n
            per_risk.append({"id": rid, "title": self.risks[rid]["title"]["en"], "goals": levels,
                             "resolved": engine.is_resolved(levels, self.rules), "lows": n})
        unresolved = [r["id"] for r in per_risk if not r["resolved"]]
        given = advice if asked and isinstance(advice, dict) else {}
        if asked and any(given.get(rid) not in ("stop", "consult") for rid in unresolved):
            raise GameError("recommend stop or consult for every risk still at High")
        answers = self._authority_answers(state)   # the risks that were sent to the authority last quarter
        decisions = [self._decide(state, r, given.get(r["id"])) for r in per_risk]
        bonus, upkeep = lows * self.rules["lowGoalBonus"], self._upkeep(state)
        state["bonus"] += bonus
        state["effort"] += bonus - upkeep   # paid at once: the coins are what keeps the run going
        state["upkeepPaid"] += upkeep
        result = {"project": state["project"] + 1, "risks": per_risk, "clean": not unresolved,
                  "highs": len(unresolved), "bonus": bonus, "upkeep": upkeep, "decisions": decisions,
                  "answers": answers,
                  "played": list(state["played"]), "paid": dict(state["paid"]),
                  "central": sorted(state["central"].values())}
        state["results"].append(result)
        state["project"] += 1
        events = [{"event": "project_ended", **result}]
        if state["project"] % self.rules["quartersPerYear"] == 0:   # a year is over: follow-ups, new purse
            events.append(self._year_end(state))
        if state["effort"] <= 0:
            state["phase"] = "done"
            state["risks"], state["played"], state["paid"] = [], [], {}
            events.append({"event": "run_finished", "coins": state["effort"], "bonus": state["bonus"],
                           "legal": state["legal"], "upkeep": state["upkeepPaid"],
                           "score": self._score(state),
                           "years": state["project"] // self.rules["quartersPerYear"]})
        else:
            self._start_project(state)
        return events

    # -- Art. 36: what happens to a risk at the end of the quarter ---------------------------------
    def _decide(self, state: State, risk: dict[str, Any], advice: str | None) -> dict[str, Any]:
        """Management decides about one risk. The player only recommends; management may see it otherwise."""
        rid = risk["id"]
        worst = max(g["score"] for g in risk["goals"])
        outcome = "live"
        if not risk["resolved"] and advice in ("stop", "consult"):
            rng = random.Random(f"{state['seed']}-q{state['project']}-management-{rid}")
            if rng.random() < self.management[state["management"]]["follows"][advice]:
                outcome = advice
        if outcome == "stop":
            state["waiting"].append(rid)
            state["yearCancelled"] += 1
            text = "Management follows the recommendation: the project is stopped and waits for next quarter."
        elif outcome == "consult":
            state["consulting"].append({"id": rid, "worst": worst})
            text = "Management follows the recommendation: the authority is consulted, answer next quarter."
        else:
            self._go_live(state, rid, worst)
            text = ("Goes live." if risk["resolved"]
                    else "Management does not share the assessment and goes live as planned.")
        return {"risk": rid, "title": risk["title"], "advice": advice, "outcome": outcome, "text": text,
                "resolved": risk["resolved"]}

    def _go_live(self, state: State, rid: str, worst: float, settled: bool = False) -> None:
        """A risk that went live is on the books until it is settled: it can come back at every year end."""
        state["yearShipped"] += 1
        if not settled:
            state["live"].append({"uid": state["liveCount"], "id": rid, "score": worst,
                                  "year": self._year(state)})
            state["liveCount"] += 1

    def _pay(self, state: State, coins: int, kind: str, risk: str) -> None:
        """Lawyers, damages and changes: coins gone, noted by kind of event and by risk for the debrief."""
        state["effort"] -= coins
        state["legal"] += coins
        state["legalByKind"][kind] = state["legalByKind"].get(kind, 0) + coins
        state["legalByRisk"][risk] = state["legalByRisk"].get(risk, 0) + coins

    def _debrief(self, state: State) -> dict[str, Any]:
        """What the end screen explains: where the coins went, what stayed open, which cards were used."""
        title = {rid: r["title"]["en"] for rid, r in self.risks.items()}
        kinds = sorted(state["legalByKind"].items(), key=lambda kv: -kv[1])
        costly = sorted(state["legalByRisk"].items(), key=lambda kv: (-kv[1], kv[0]))[:5]
        last_year = max(1, (state["project"] - 1) // self.rules["quartersPerYear"] + 1)
        open_risks: dict[str, dict[str, Any]] = {}
        for entry in state["live"]:   # went live at High and was never settled
            if entry["score"] <= self._high_from():
                continue
            row = open_risks.setdefault(entry["id"], {"risk": entry["id"], "title": title[entry["id"]],
                                                      "years": 0, "worst": 0})
            row["years"] = max(row["years"], last_year - entry["year"] + 1)
            row["worst"] = max(row["worst"], entry["score"])
        for row in open_risks.values():
            risk, measures = self.risks[row["risk"]], list(self.cards.values())
            found = risk_check.cheapest_resolution(risk, measures, self.rules)
            row["cost"], ids = (None, []) if found is None else found
            row["cards"] = [{"id": i, "title": self.cards[i]["title"]["en"]} for i in ids]
        played = {cid for res in state["results"] for cid in res["played"]} | set(state["played"])
        used = sorted(cid for cid in played if cid in self.cards)
        return {
            "legal": {"total": state["legal"], "byKind": [{"kind": k, "coins": v} for k, v in kinds],
                      "byRisk": [{"risk": r, "title": title[r], "coins": v} for r, v in costly]},
            "upkeep": state["upkeepPaid"],
            "open": sorted(open_risks.values(), key=lambda r: (-r["years"], r["risk"])),
            "cards": [{"id": i, "title": self.cards[i]["title"]["en"],
                       "sdm": list(self.cards[i].get("sdmRefs", [])),
                       "nist": list(self.cards[i].get("nistRefs", []))} for i in used],
        }

    def _authority_answers(self, state: State) -> list[dict[str, Any]]:
        """The authority answers the risks that were sent to it in the quarter before."""
        cfg, out = self.rules["authority"], []
        for entry in state["consulting"]:
            title = self.risks[entry["id"]]["title"]["en"]
            if entry["worst"] > cfg["refusesAbove"]:
                state["yearCancelled"] += 1
                cost = cfg["refusalCost"]
                text = f"The authority does not allow it: the project is cancelled, lawyers cost {cost}."
                outcome = "refused"
            else:
                self._go_live(state, entry["id"], entry["worst"], settled=True)
                cost = cfg["adviceCost"]
                text = f"The authority advises: lawyers and changes cost {cost}, then it goes live, settled."
                outcome = "advice"
            self._pay(state, cost, outcome, entry["id"])
            out.append({"risk": entry["id"], "title": title, "outcome": outcome, "cost": cost, "text": text})
        state["consulting"] = []
        return out

    # -- year end: the risks that went live may come back --------------------------------------------
    @staticmethod
    def _band(table: list[dict[str, Any]], score: float) -> float:
        return next((row["chance"] for row in table if score <= row["upTo"]), table[-1]["chance"])

    def _year_end(self, state: State) -> dict[str, Any]:
        year, rules = self._year(state) - 1, self.rules
        books = list(state["live"])   # every risk on the books rolls, so every risk is reported
        follow = self._follow_ups(state, year)
        hit = {n["uid"] for n in follow}
        quiet = [{"risk": e["id"], "title": self.risks[e["id"]]["title"]["en"], "years": year - e["year"] + 1,
                  "chance": round(100 * self._chance(e, year))} for e in books if e["uid"] not in hit]
        base = self._purse(state["difficulty"])
        budget = max(0, base + rules["goLiveBonus"] * state["yearShipped"]
                     - rules["cancelMalus"] * state["yearCancelled"])
        state["effort"] += budget
        event = {"event": "year_ended", "year": year, "base": base, "budget": budget,
                 "shipped": state["yearShipped"], "cancelled": state["yearCancelled"], "followUps": follow,
                 "quiet": quiet}
        state["yearShipped"] = state["yearCancelled"] = 0
        return event

    def _chance(self, entry: dict[str, Any], year: int) -> float:
        """The chance that a live risk brings something at the end of the year."""
        cfg = self.rules["followUp"]
        base = self._band(cfg["chance"], entry["score"])
        return min(cfg["maxChance"], base + cfg["perYear"] * (year - entry["year"]))

    def _follow_ups(self, state: State, year: int) -> list[dict[str, Any]]:
        """Every live risk rolls: a report, an inquiry or a lawsuit. The higher it was and the longer it runs,
        the likelier. A report can set off a second, worse event."""
        cfg, notes = self.rules["followUp"], []
        for entry in list(state["live"]):
            rng = random.Random(f"{state['seed']}-follow{year}-{entry['uid']}")
            if rng.random() >= self._chance(entry, year):
                continue
            names = list(cfg["outcomes"])
            kind = rng.choices(names, weights=[cfg["outcomes"][n]["weight"] for n in names])[0]
            notes.append(self._hit(state, entry, kind, rng, 1.0, 0.0))
            chain = cfg["reportChain"]
            if kind == "report" and rng.random() < chain["chance"]:
                more = list(chain["weights"])
                kind2 = rng.choices(more, weights=[chain["weights"][n] for n in more])[0]
                notes.append(self._hit(state, entry, kind2, rng, chain["costFactor"],
                                       chain["loseChanceAdd"], True))
        return notes

    def _hit(self, state: State, entry: dict[str, Any], kind: str, rng: random.Random, factor: float,
             lose_add: float, after_report: bool = False) -> dict[str, Any]:
        """One event of a live risk: pay the lawyers (and perhaps damages). A settled risk does not return."""
        o = self.rules["followUp"]["outcomes"][kind]
        cost, closed = round(o["lawyers"] * factor), False
        what = {"report": "A report from an employee or a customer",
                "authority": "The authority starts an inquiry", "lawsuit": "A lawsuit",
                "massLawsuit": "A mass lawsuit"}[kind]
        if kind == "authority":
            cost += round(o["changes"] * factor)
            closed, tail = True, "lawyers and the changes cost {cost} coins, the risk is settled"
        elif kind in ("lawsuit", "massLawsuit"):
            if rng.random() < o["loseChance"] + lose_add:
                cost += round(o["damages"] * factor)
                tail = "lost: lawyers and damages cost {cost} coins"
            else:
                closed, tail = True, "won: the lawyers still cost {cost} coins, the risk is settled"
        else:
            tail = "lawyers cost {cost} coins"
        self._pay(state, cost, kind, entry["id"])
        if closed and entry in state["live"]:
            state["live"].remove(entry)
        return {"risk": entry["id"], "uid": entry["uid"], "title": self.risks[entry["id"]]["title"]["en"],
                "kind": kind, "cost": cost, "closed": closed, "afterReport": after_report,
                "text": f"{what}: {tail.format(cost=cost)}."}

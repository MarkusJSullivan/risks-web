"""Can every risk be resolved with affordable cards? (v0.8+)

For each risk the cheapest set of measure cards that brings every goal of the risk below High, within the card
slots of one quarter and with at most one card per ladder (family). Prices are the first-time prices of the
simple mode; events and strategy cards are left out. The yearly purse is the yardstick for "affordable".
"""
from __future__ import annotations

from typing import Any

from . import engine
from .cards import CardSet

Card = dict[str, Any]


def cheapest_resolution(risk: Card, cards: list[Card], rules: dict[str, Any],
                        slots: int | None = None) -> tuple[int, list[str]] | None:
    """(cost, card ids) of the cheapest set that resolves the risk, ``(0, [])`` if it starts resolved, or None
    if no set of at most ``slots`` cards does."""
    slots = rules["maxCardsPerProject"] if slots is None else slots
    goals = {g["goal"] for g in risk["goals"]}
    useful = [c for c in cards if any(e["goal"] in goals and (e["probability"] > 0 or e["impact"] > 0)
                                      for e in c["effects"])]
    useful.sort(key=lambda c: (c["effort"], c["id"]))

    def resolved(chosen: list[Card]) -> bool:
        return engine.is_resolved(engine.risk_goal_levels(risk, chosen, rules), rules)

    if resolved([]):
        return 0, []
    best: tuple[int, list[str]] | None = None

    def search(start: int, chosen: list[Card], cost: int, families: set[str]) -> None:
        nonlocal best
        for i in range(start, len(useful)):
            card = useful[i]
            price = cost + card["effort"]
            if best is not None and price >= best[0]:
                break   # the cards are sorted by price: nothing further along is cheaper
            if card["family"] in families:
                continue
            now = [*chosen, card]
            if resolved(now):
                best = (price, [c["id"] for c in now])
            elif len(now) < slots:
                search(i + 1, now, price, families | {card["family"]})

    search(0, [], 0, set())
    return best


def check_risks(cs: CardSet) -> list[dict[str, Any]]:
    """One row per risk: where it starts, the cheapest resolution, and what is wrong with it (if anything)."""
    rules = cs.rules
    cards = [c for c in cs.data["measureCards"] if c["type"] in ("standard", "learning", "permanent")]
    rows = []
    for risk in cs.risks:
        levels = engine.risk_goal_levels(risk, [], rules)
        found = cheapest_resolution(risk, cards, rules)
        issue = None
        if found is not None and found[0] == 0:
            issue = "starts below High: nothing to do"
        elif found is None:
            issue = f"cannot be brought below High with {rules['maxCardsPerProject']} cards"
        elif found[0] > rules["effortBudget"]:
            issue = f"the cheapest set costs {found[0]}, more than the yearly purse ({rules['effortBudget']})"
        cost, ids = (None, None) if found is None else found
        rows.append({"id": risk["id"], "title": risk["title"]["en"], "worst": max(g["score"] for g in levels),
                     "cost": cost, "cards": ids, "issue": issue})
    return rows


def report(cs: CardSet) -> str:
    rows = check_risks(cs)
    lines = [f"{'risk':5} {'worst':>6} {'cost':>5}  cheapest set"]
    for r in rows:
        cost = "-" if r["cost"] is None else str(r["cost"])
        lines.append(f"{r['id']:5} {r['worst']:>6} {cost:>5}  {', '.join(r['cards'] or []) or '-'}")
    problems = [r for r in rows if r["issue"]]
    lines += ["", f"{len(problems)} of {len(rows)} risks have an issue:" if problems
              else f"All {len(rows)} risks can be resolved within the yearly purse."]
    lines += [f"  {r['id']} {r['title']}: {r['issue']}" for r in problems]
    return "\n".join(lines)

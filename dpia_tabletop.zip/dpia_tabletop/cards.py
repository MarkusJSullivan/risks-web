"""Loading and lookup of a versioned card set.

Data lives in ``data/<version>/`` (e.g. ``data/v0.8/``), split into:
game.json, rules.json, measures.json, specials.json, risks.json, design.json, events.json and
management.json.
``data/versions.json`` names the default version.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any

from .engine import Card

DATA_FILES = ("game", "rules", "measures", "specials", "risks", "design", "events", "management")


def data_root() -> Path:
    return Path(str(resources.files("dpia_tabletop") / "data"))


def available_versions() -> list[str]:
    return sorted(
        (p.name.removeprefix("v") for p in data_root().iterdir() if p.is_dir() and p.name.startswith("v")),
        key=lambda v: tuple(int(x) for x in v.split(".")),
    )


def default_version() -> str:
    return json.loads((data_root() / "versions.json").read_text(encoding="utf-8"))["default"]


def _read(directory: Path, name: str) -> Any:
    return json.loads((directory / f"{name}.json").read_text(encoding="utf-8"))


@dataclass
class CardSet:
    data: dict[str, Any]
    version: str = ""
    by_id: dict[str, Card] = field(init=False)

    def __post_init__(self) -> None:
        cards = self.data["measureCards"] + self.data["riskCards"] + self.data.get("eventCards", [])
        self.by_id = {c["id"]: c for c in cards}

    @classmethod
    def load(cls, version: str | None = None, path: str | Path | None = None) -> CardSet:
        """Load a version from the bundled data, or any version directory given as ``path``."""
        if path is not None:
            directory, label = Path(path), Path(path).name.removeprefix("v")
        else:
            label = (version or default_version()).removeprefix("v")
            directory = data_root() / f"v{label}"
            if not directory.is_dir():
                raise ValueError(f"unknown version {label!r}; available: {', '.join(available_versions())}")
        parts = {name: _read(directory, name) for name in DATA_FILES}
        data = {
            "game": {**parts["game"], "rules": parts["rules"]},
            "measureCards": parts["measures"] + parts["specials"],
            "riskCards": parts["risks"],
            "eventCards": parts["events"],
            "managementCards": parts["management"],
            "design": parts["design"],
        }
        return cls(data, label)

    @property
    def rules(self) -> dict[str, Any]:
        return self.data["game"]["rules"]

    @property
    def design(self) -> dict[str, Any]:
        return self.data["design"]

    @property
    def goal_ids(self) -> list[str]:
        return [g["id"] for g in self.data["game"]["protectionGoals"]]

    @property
    def risks(self) -> list[Card]:
        return self.data["riskCards"]

    def level(self, score: float) -> str:
        from .engine import level_name

        return level_name(score, self.rules["riskLevels"])

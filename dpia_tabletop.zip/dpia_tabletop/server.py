"""Authoritative game server (standard library only).

The server owns every game state. The browser sends an *action* and gets back a *view*: only what
the player may see, never the state itself. A player cannot edit rules, budget or the deck, and a
future online version only has to add accounts and storage on top.

The rules plug in through ``GameLogic``; this module knows nothing about cards or protection goals.
The v0.8 rules engine will implement that interface.

Endpoints (JSON in, JSON out)::

    POST /api/new     {"seed": 1, "handSize": 7, "mode": "simple", "difficulty": "hard"}
                                                             -> {"session": "...", "view": {...}}
    POST /api/<session>/action  {"type": "...", ...}     -> {"view": {...}, "events": [...]}
    GET  /api/<session>/view                             -> {"view": {...}}
    POST /api/clientlog         {"message": "...", ...}  -> {"ok": true}   (the page reports its errors)

What happens is written to the log (see ``logs.py``); the log never holds a session token in full.
"""
from __future__ import annotations

import json
import logging
import mimetypes
import os
import re
import secrets
import threading
import time
from collections import OrderedDict
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import parse_qs

MAX_BODY_BYTES = 16 * 1024
MAX_SESSIONS = 200
SESSION_TTL_SECONDS = 4 * 60 * 60
LOCAL_HOSTS = {"127.0.0.1", "localhost", "[::1]"}
TOKEN = re.compile(r"^[A-Za-z0-9_-]{16,64}$")   # what token_urlsafe gives; also the name of a saved file
ART_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*\.(png|jpg|jpeg|webp|svg)$")

TOKEN_IN_PATH = re.compile(r"/api/([A-Za-z0-9_-]{6})[A-Za-z0-9_-]{10,}")
log = logging.getLogger("dpia_tabletop")
log.addHandler(logging.NullHandler())   # quiet unless the server sets a log file up

State = dict[str, Any]
Action = dict[str, Any]


class GameError(Exception):
    """A move the rules do not allow. The message is safe to show the player."""


class GameLogic(Protocol):
    def new_game(self, seed: int | None, hand_size: int | None = None, mode: str | None = None,
                 difficulty: str | None = None) -> State: ...

    def apply(self, state: State, action: Action) -> tuple[State, list[dict[str, Any]]]:
        """Return the new state and the events it caused. Raise GameError for an illegal action."""

    def view(self, state: State) -> dict[str, Any]:
        """What the player may see: no undrawn deck order, no seed, no facilitator material."""


class SessionStore:
    """Sessions with a size cap and an idle timeout (single process, single player).

    They live in memory. With a ``directory`` every session is also saved there as ``<token>.json`` after each
    move and read back when the token is asked for after a restart; a file that nobody has touched for the
    idle timeout is deleted. The state holds the seed and the deck: keep the directory private to the machine.
    """

    def __init__(self, max_sessions: int = MAX_SESSIONS, ttl: float = SESSION_TTL_SECONDS,
                 clock=time.monotonic, directory: str | Path | None = None) -> None:
        self._max, self._ttl, self._clock = max_sessions, ttl, clock
        self._items: OrderedDict[str, tuple[float, State]] = OrderedDict()
        self.lock = threading.Lock()
        self._dir = Path(directory) if directory else None
        if self._dir:
            self._dir.mkdir(parents=True, exist_ok=True)
            for old in self._dir.glob("*.json"):   # what nobody touched for the idle timeout is gone
                if time.time() - old.stat().st_mtime > self._ttl:
                    old.unlink(missing_ok=True)

    def _file(self, token: str) -> Path | None:
        """The file of a session, or None if nothing is saved or the token is not one the store made."""
        return self._dir / f"{token}.json" if self._dir and TOKEN.match(token) else None

    def _save(self, token: str, state: State) -> None:
        path = self._file(token)
        if path is not None:
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(state), encoding="utf-8")
            os.replace(tmp, path)   # a crash never leaves half a file

    def _load(self, token: str) -> State | None:
        path = self._file(token)
        if path is None or not path.is_file():
            return None
        if time.time() - path.stat().st_mtime > self._ttl:
            path.unlink(missing_ok=True)
            return None
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        log.info("session %s read back from disk", token[:6])
        return state

    def _expire(self) -> None:
        now = self._clock()
        for key in [k for k, (seen, _) in self._items.items() if now - seen > self._ttl]:
            del self._items[key]

    def create(self, state: State) -> str:
        self._expire()
        while len(self._items) >= self._max:
            self._items.popitem(last=False)  # drop the least recently used
        token = secrets.token_urlsafe(24)
        self._items[token] = (self._clock(), state)
        self._save(token, state)
        return token

    def get(self, token: str) -> State | None:
        self._expire()
        entry = self._items.get(token)
        if entry is None:
            state = self._load(token)   # saved by an earlier run of the server, or pushed out of memory
            if state is None:
                return None
            entry = (self._clock(), state)
        self._items[token] = (self._clock(), entry[1])
        self._items.move_to_end(token)
        path = self._file(token)
        if path is not None and path.is_file():
            os.utime(path)   # seen just now: the idle timeout starts again
        return entry[1]

    def put(self, token: str, state: State) -> None:
        self._items[token] = (self._clock(), state)
        self._items.move_to_end(token)
        self._save(token, state)

    def __len__(self) -> int:
        return len(self._items)


def make_handler(logic: GameLogic, store: SessionStore, page: bytes | None = None,
                 pages: dict[str, bytes] | None = None, style_art: dict[str, Path] | None = None):
    """``pages`` maps a card style id to its page (the first is the default, chosen with ``?style=``);
    ``style_art`` maps a style id to its picture folder, served as ``/art/<style id>/<file>``."""
    style_art = style_art or {}
    class Handler(BaseHTTPRequestHandler):
        server_version = "dpia-tabletop"

        def log_message(self, format: str, *args: Any) -> None:   # not on the console, but in the log file
            line = TOKEN_IN_PATH.sub(r"/api/\1...", format % args)
            if "/art/" not in line:   # pictures are not worth a line each
                log.info("request %s", line)

        # -- helpers -------------------------------------------------------------------------
        def _send(self, status: int, payload: dict[str, Any] | bytes,
                  ctype: str = "application/json", cache: str = "no-store") -> None:
            body = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")
            self.send_response(status)
            text = ctype.startswith(("text/", "application/json"))
            self.send_header("Content-Type", f"{ctype}; charset=utf-8" if text else ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def _error(self, status: HTTPStatus, message: str) -> None:
            self._send(status, {"error": message})

        def _masked(self) -> str:
            return TOKEN_IN_PATH.sub(r"/api/\1...", self.path)

        @staticmethod
        def _what(action: dict[str, Any]) -> dict[str, Any]:
            return {k: action[k] for k in ("type", "card", "target", "cards", "advice") if k in action}

        def _host_ok(self) -> bool:
            """Refuse foreign Host headers (DNS rebinding) and cross-site POSTs (CSRF)."""
            header = self.headers.get("Host") or ""
            name = header.split("]")[0] + "]" if header.startswith("[") else header.split(":")[0]
            if name not in LOCAL_HOSTS:
                return False
            origin = self.headers.get("Origin")
            if origin and self.command == "POST":
                return origin.split("://", 1)[-1] == header
            return True

        def _body(self) -> dict[str, Any] | None:
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = -1
            if not 0 <= length <= MAX_BODY_BYTES:
                self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "body too large")
                return None
            if (self.headers.get("Content-Type") or "").split(";")[0].strip() != "application/json":
                self.rfile.read(length)  # drain, so the client is not cut off mid-send
                self._error(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "send application/json")
                return None
            try:
                data = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError:
                self._error(HTTPStatus.BAD_REQUEST, "invalid JSON")
                return None
            if not isinstance(data, dict):
                self._error(HTTPStatus.BAD_REQUEST, "expected a JSON object")
                return None
            return data

        def _guard(self, route) -> None:
            """A bug in the server is logged with its traceback and answered, not left to hang the page."""
            try:
                route()
            except (BrokenPipeError, ConnectionResetError):
                log.warning("client went away during %s %s", self.command, self._masked())
            except Exception:
                log.exception("unhandled error in %s %s", self.command, self._masked())
                try:
                    self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal error, see var/logs")
                except OSError:
                    pass

        # -- routes --------------------------------------------------------------------------
        def do_GET(self) -> None:
            self._guard(self._get)

        def do_POST(self) -> None:
            self._guard(self._post)

        def _get(self) -> None:
            if not self._host_ok():
                return self._error(HTTPStatus.FORBIDDEN, "local access only")
            path, _, query = self.path.partition("?")
            parts = [p for p in path.split("/") if p]
            if not parts and pages:
                wanted = parse_qs(query).get("style", [""])[0]
                return self._send(HTTPStatus.OK, pages.get(wanted) or next(iter(pages.values())), "text/html")
            if not parts and page is not None:
                return self._send(HTTPStatus.OK, page, "text/html")
            if len(parts) == 3 and parts[0] == "art" and parts[1] in style_art:
                return self._send_art(parts[2], style_art[parts[1]])
            if len(parts) == 3 and parts[:1] == ["api"] and parts[2] == "view":
                with store.lock:
                    state = store.get(parts[1])
                    if state is None:
                        return self._error(HTTPStatus.NOT_FOUND, "unknown or expired session")
                    return self._send(HTTPStatus.OK, {"view": logic.view(state)})
            self._error(HTTPStatus.NOT_FOUND, "not found")

        def _send_art(self, name: str, folder: Path) -> None:
            """Card art from an art folder: only plain picture file names, nothing outside the folder."""
            path = (folder / name) if ART_NAME.match(name) else None
            if path is None or not path.is_file() or path.resolve().parent != folder.resolve():
                return self._error(HTTPStatus.NOT_FOUND, "not found")
            ctype = mimetypes.guess_type(name)[0] or "application/octet-stream"
            self._send(HTTPStatus.OK, path.read_bytes(), ctype, cache="public, max-age=3600")

        def _post(self) -> None:
            if not self._host_ok():
                return self._error(HTTPStatus.FORBIDDEN, "local access only")
            parts = [p for p in self.path.split("?")[0].split("/") if p]
            body = self._body()
            if body is None:
                return None
            if parts == ["api", "clientlog"]:   # an error in the page: bounded text, nothing else
                text = {k: str(body.get(k, ""))[:limit] for k, limit in
                        (("message", 500), ("where", 200), ("stack", 2000), ("session", 6))}
                log.error("browser error: %s | where %s | session %s\n%s", text["message"], text["where"],
                          text["session"], text["stack"])
                return self._send(HTTPStatus.OK, {"ok": True})
            if parts == ["api", "new"]:
                seed = body.get("seed")
                if seed is not None and (isinstance(seed, bool) or not isinstance(seed, int)):
                    return self._error(HTTPStatus.BAD_REQUEST, "seed must be an integer")
                try:   # the rules know the limits of the hand size and say so
                    state = logic.new_game(seed, body.get("handSize"), body.get("mode"),
                                           body.get("difficulty"))
                except GameError as exc:
                    return self._error(HTTPStatus.BAD_REQUEST, str(exc))
                with store.lock:
                    token = store.create(state)
                log.info("new game %s version=%s seed=%s hand=%s mode=%s difficulty=%s", token[:6],
                         state.get("version"), state.get("seed"), body.get("handSize"), state.get("mode"),
                         state.get("difficulty"))
                return self._send(HTTPStatus.OK, {"session": token, "view": logic.view(state)})
            if len(parts) == 3 and parts[0] == "api" and parts[2] == "action":
                with store.lock:  # one action at a time: no two requests can race on one state
                    state = store.get(parts[1])
                    if state is None:
                        return self._error(HTTPStatus.NOT_FOUND, "unknown or expired session")
                    try:
                        new_state, events = logic.apply(state, body)
                    except GameError as exc:
                        log.info("refused %s %s: %s", parts[1][:6], self._what(body), exc)
                        return self._error(HTTPStatus.CONFLICT, str(exc))
                    store.put(parts[1], new_state)
                    log.info("action %s %s -> %s", parts[1][:6], self._what(body),
                             [e.get("event") for e in events])
                    return self._send(HTTPStatus.OK, {"view": logic.view(new_state), "events": events})
            self._error(HTTPStatus.NOT_FOUND, "not found")

    return Handler


def make_server(logic: GameLogic, host: str = "127.0.0.1", port: int = 8000,
                store: SessionStore | None = None, page: bytes | None = None,
                pages: dict[str, bytes] | None = None,
                style_art: dict[str, Path] | None = None) -> ThreadingHTTPServer:
    handler = make_handler(logic, store if store is not None else SessionStore(), page, pages, style_art)
    return ThreadingHTTPServer((host, port), handler)

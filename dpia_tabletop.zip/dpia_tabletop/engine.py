"""Rule logic of the pool model (v0.8+): goal values, risk levels, resolved risks and costs.

Pure functions without I/O, shared by the offline game and a future online server. Every number comes
from the rules data. The rules of the older card sets (v0.6 and v0.7) are in ``engine_v07``.
"""
from __future__ import annotations

from collections.abc import Iterable
from typing import Any

Card = dict[str, Any]


# ---------------------------------------------------------------------------------------------------
# Pool model (v0.8+). A risk lists goals with a starting probability and impact. A measure carries
# effects per goal; a positive number lowers the value, a negative number raises it (a downside).
# Only goals printed on the risk count; a measure applies to every risk in the project that lists
# the goal. Values are recomputed from the risk's start and the cards in play, so replacing a card
# of a ladder needs no undo. All numbers come from the rules data.
# ---------------------------------------------------------------------------------------------------

Bounds = tuple[int, int]


def _clamp(value: int, bounds: Bounds) -> int:
    return max(bounds[0], min(bounds[1], value))


def goal_values(risk_goal: dict[str, Any], active: Iterable[Card], bounds: Bounds,
                shift: tuple[int, int] = (0, 0)) -> tuple[int, int]:
    """(probability, impact) of one risk goal with the cards in play.

    ``shift`` is what events did to the risk: positive makes the goal worse, negative better.
    """
    goal = risk_goal["goal"]
    dp = di = 0
    for card in active:
        for e in card.get("effects", []):
            if e["goal"] == goal:
                dp += e["probability"]
                di += e["impact"]
    return (_clamp(risk_goal["probability"] + shift[0] - dp, bounds),
            _clamp(risk_goal["impact"] + shift[1] - di, bounds))


def level_name(score: int, levels: list[dict[str, Any]]) -> str:
    for lvl in levels:
        lo, hi = lvl["range"]
        if lo <= score <= hi:
            return lvl["level"]["en"]
    raise ValueError(f"score {score} outside all risk levels")


def risk_goal_levels(risk: Card, active: Iterable[Card], rules: dict[str, Any],
                     shifts: dict[str, tuple[int, int]] | None = None) -> list[dict[str, Any]]:
    """Per goal of the risk: start and current probability and impact, score and level name.

    ``shifts`` maps a goal to the (probability, impact) change that events made to this risk.
    """
    b = rules["valueBounds"]
    bounds = (b["min"], b["max"])
    cards = list(active)
    out = []
    for g in risk["goals"]:
        p, i = goal_values(g, cards, bounds, tuple((shifts or {}).get(g["goal"], (0, 0))))
        out.append({"goal": g["goal"], "start": (g["probability"], g["impact"]), "now": (p, i),
                    "score": p * i, "level": level_name(p * i, rules["riskLevels"])})
    return out


def is_resolved(goal_levels: list[dict[str, Any]], rules: dict[str, Any]) -> bool:
    """A risk is resolved when every listed goal is below the level named in ``resolvedBelow``."""
    names = [lv["level"]["en"] for lv in rules["riskLevels"]]
    limit = names.index(rules["resolvedBelow"])
    return all(names.index(g["level"]) < limit for g in goal_levels)


def low_goals(goal_levels: list[dict[str, Any]], rules: dict[str, Any]) -> int:
    """How many goals of the risk are at the lowest level (below Medium). Each earns a bonus."""
    lowest = rules["riskLevels"][0]["level"]["en"]
    return sum(1 for g in goal_levels if g["level"] == lowest)


def effort_cost(card: Card, learned: Iterable[str]) -> int:
    """Shareable cards cost their reuse price once they have been played in an earlier project."""
    if card["type"] == "learning" and card["id"] in set(learned) and card.get("effortWhenExisting"):
        return card["effortWhenExisting"]
    return card["effort"]
